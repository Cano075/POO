/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PIA;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class Main {

    public static void main(String[] args) {
        Main obj = new Main();
        obj.run(args);
    }

    Acceso acceso = new Acceso();
    Administracion administracion = new Administracion();
    //Servicios servicios = new Servicios();
    Servicios servicios[] = new Servicios[10];

    Citas citas = new Citas();
    Venta venta = new Venta();

    public void run(String[] args) {
        //esto tendría que leerlo de un txt
        servicios[0] = new Servicios("Corte de Pelo", 200);
        servicios[1] = new Servicios("Baño", 150);
        servicios[2] = new Servicios("Vacunación", 250);

        Acceso.main();
        menu();

    }

    public void menu() {
        int aux = 0;
        int opc;
        Scanner teclado = new Scanner(System.in);
        do {
            System.out.println("Bienvenido al menú. \n");
            System.out.println("\t1-.Administración \n");
            System.out.println("\t2-.Ventas \n");
            System.out.println("\t3-.Buscar \n");
            System.out.println("\t4-.Salir \n");
            System.out.println("\t\t Opción: ");
            opc = teclado.nextInt();

            switch (opc) {
                case 1:
                    administracion();
                    break;
                case 2:
                    ventas();
                    break;
                case 3:
                    venta.buscar();
                    break;
                case 4:
                    aux = 1;
                    break;
                default:
                    System.out.println("Escoja una opción válida. \n");
                    break;
            }

        } while (aux == 0);
    }

    public void administracion() {
        int aux = 0;
        int opc;

        Scanner teclado = new Scanner(System.in);

        do {
            System.out.println("Administración: \n");
            System.out.println("\t1-Modificar ventas. \n");
            System.out.println("\t2-Modificar servicios. \n");
            System.out.println("\t3-. \n");
            System.out.println("\t4-.Salir \n");
            System.out.println("\t\t Opción: ");
            opc = teclado.nextInt();

            switch (opc) {
                case 1:
                    venta.imprimirVentas();
                    System.out.println("\t\t Venta: ");
                    int ticket = teclado.nextInt();
                    ticket--;
                    if (venta.validarBusqueda(ticket)) {
                        System.out.println("Escoja un servicio: \n");
                        imprimirServicios();
                        System.out.println("\tOpcion: ");
                        int a = teclado.nextInt();
                        a--;
                        teclado.nextLine();
                        System.out.println("Ingrese su nombre: ");
                        String nuevoCliente = teclado.nextLine();
                        System.out.println("Ingrese su número: ");
                        String nuevoNumero = teclado.nextLine();
                        venta.modificarVenta(ticket, nuevoCliente, servicios[a].getNombreServicio(), nuevoNumero);
                    } else {
                        System.out.println("Ticket no válido. \n");
                    }
                    aux=1;
                    break;
                case 2:

                    System.out.println("\t1-Agregar Servicio. \n");
                    System.out.println("\t2-Modificar Servicio. \n");
                    System.out.println("\t3-Eliminar. \n");
                    int a = teclado.nextInt();
                    int b;
                    switch (a) {
                        case 1:
                            agregarServicio();
                            break;
                        case 2:
                            System.out.println("Escoja un servicio: \n");
                            imprimirServicios();
                            System.out.println("\tOpcion: ");
                            b = teclado.nextInt();
                            b--;
                            if (validarServicio(b)) {
                                modificarServicio(b);
                            }
                            break;
                        case 3:
                            System.out.println("Escoja un servicio: \n");
                            imprimirServicios();
                            System.out.println("\tOpcion: ");
                            b = teclado.nextInt();
                            b--;
                            if (validarServicio(b)) {
                                eliminarServicio(b);
                            }
                            break;
                        default:
                            System.out.println("\tOpción no válida. \n");
                    }
                    aux=1;
                    break;
                case 3:
                    
                    break;
                case 4:
                    aux = 1;
                    break;
                default:
                    System.out.println("Escoja una opción válida. \n");
                    break;
            }

        } while (aux == 0);
    }
    int id = 0;

    public void ventas() {
        int aux = 0;
        int opc;
        Scanner teclado = new Scanner(System.in);

        do {
            System.out.println("Ventas: \n");
            System.out.println("\t1-.Agregar venta\n");
            System.out.println("\t2-.Imprimir ventas\n");
            //System.out.println("\t3-. \n");
            System.out.println("\t3-.Salir \n");
            System.out.println("\t Opción: ");
            opc = teclado.nextInt();

            switch (opc) {
                case 1:
                    System.out.println("Escoja un servicio: \n");
                    int a = 0;
                    imprimirServicios();
                    System.out.println("\tOpcion: ");
                    a = teclado.nextInt();
                    a--;
                    teclado.nextLine();
                    System.out.println("Ingrese su nombre: ");
                    String cliente = teclado.nextLine();
                    System.out.println("Ingrese su número: ");
                    String numero = teclado.nextLine();
                    venta.Vender(cliente, numero, servicios[a], id);
                    id++;
                    aux = 0;
                    break;
                case 2:
                    venta.imprimirVentas();
                    break;
                case 3:
                    aux = 1;
                    break;
                default:
                    System.out.println("Escoja una opción válida. \n");
                    break;
            }

        } while (aux == 0);
    }

    public void imprimirServicios() {
        int a = 0;
        while (servicios[a] != null) {
            System.out.println("\t" + (a + 1) + "-." + servicios[a].getNombreServicio() + "\n");
            a++;
        }
    }

    public boolean validarServicio(int x) {
        return servicios[x] != null;
    }

    public void modificarServicio(int x) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese el nombre: ");
        String nombre = teclado.nextLine();
        System.out.println("Ingrese el precio: ");
        double numero = teclado.nextDouble();
        servicios[x].setCostoServicio(numero);
        servicios[x].setNombreServicio(nombre);
    }

    public void agregarServicio() {
        int i = 0;
        while (servicios[i] != null) {
            i++;
        }
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese el nombre: ");
        String nombre = teclado.nextLine();
        System.out.println("Ingrese el precio: ");
        double numero = teclado.nextDouble();
        servicios[i] = new Servicios(nombre,numero);
        
    }

    public void eliminarServicio(int x) {
        int i = 0;
        if (servicios[1] == null) { //caso único
            servicios[0] = null;
        } else {
            while (servicios[i + 1] != null) {
                i++;
            }
            servicios[x] = servicios[i];
            servicios[i] = null;
        }
    }
}
    
  
