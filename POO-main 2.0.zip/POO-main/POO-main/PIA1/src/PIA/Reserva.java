package PIA;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Reserva {
    
    private String cliente;
    private String numero;
    private String servicio;
    private int ID;
    
    Reserva reserva[]= new Reserva[10];

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }
    
    
    public Reserva(String cliente, String numero, String servicio, int ID) {
        this.cliente = cliente;
        this.numero = numero;
        this.servicio = servicio;
        this.ID = ID;
    }
    public Reserva(){
        
    }
    public void Reservar(String cliente, String numero, String servicio, int ID){
        reserva[ID]=new Reserva(cliente, numero, servicio,ID);
    }
    
    public void imprimirReservas(){
        int x=0;
        while(reserva[x]!=null){
        System.out.print(reserva[x]);
        x++;
        }
    }
    
    @Override
    public String toString(){
        return "Información de la cita: " + ID + "\n" + 
               "Cliente: " + cliente + "\n" +
               "Numero: " + numero+"\n"+
               "Servicio: "+ servicio + "\n" ;
    }
}
