/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PIA;

import java.util.Scanner;

/**
 *
 * @author admin
 */
public class Administracion {
    Reserva reservacion2 = new Reserva();
    public void administracion(){
        int aux = 0;
        int opc;
        Scanner teclado = new Scanner(System.in);
        
        do{
          System.out.println("Administración: \n");
          System.out.println("\t1-Modificar reservaciones. \n");
          System.out.println("\t2-Modificar servicios. \n");
          System.out.println("\t3-. \n");
          System.out.println("\t4-.Salir \n");
          System.out.println("\t\t Opción: ");
          opc=teclado.nextInt();
          
          switch(opc){
              case 1:
                  //modificarReservacion(); //no existe
                  break;
              case 2:
                  
                  break;
              case 3:
                  
                  break;
              case 4:
                  aux=1;
                  break;
              default:
                  System.out.println("Escoja una opción válida. \n");
                  break;
          }
          
        }while(aux==0);
    }
}
