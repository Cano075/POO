/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PIA;
import Servicios.Servicios;
import java.util.Scanner;
/**
 *
 * @author admin
 */
public class Main {
     public static void main(String[] args) {
       Main obj =  new Main();
       obj.run(args);
    }
    Acceso acceso = new Acceso();
    Administracion administracion = new Administracion();
    Servicios servicio = new Servicios();
    Citas citas = new Citas();
    
    public void run(String[] args){
        acceso.main();
        menu();
        
    }
    public void menu(){
        int aux = 0;
        int opc;
        Scanner teclado = new Scanner(System.in);
        do{
          System.out.println("Bienvenido al menú. \n");
          System.out.println("\t1-.Administración \n");
          System.out.println("\t2-.Citas \n");
          System.out.println("\t3-.Buscar \n");
          System.out.println("\t4-.Salir \n");
          System.out.println("\t\t Opción: ");
          opc=teclado.nextInt();
          
          switch(opc){
              case 1:
                  administracion.administracion();
                  break;
              case 2:
                  citas.citas();
                  break;
              case 3:
                  
                  break;
              case 4:
                  aux=1;
                  break;
              default:
                  System.out.println("Escoja una opción válida. \n");
                  break;
          }
          
        }while(aux==0);
    }
    
}
