/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PIA;

import java.util.Scanner;

public class Citas {
    int id=0;
    Reserva reservacion = new Reserva();
    public void citas(){
        int aux = 0;
        int opc;
        Scanner teclado = new Scanner(System.in);
        
        do{
          System.out.println("Citas: \n");
          System.out.println("\t1-.Agregar \n");
          System.out.println("\t2-.Imprimir Citas\n");
          System.out.println("\t3-. \n");
          System.out.println("\t4-.Salir \n");
          System.out.println("\t Opción: ");
          opc=teclado.nextInt();
          
          switch(opc){
              case 1:
                  System.out.println("Escoja un servicio: \n");
                  System.out.println("\t1-.Corte de pelo \n");
                  System.out.println("\t2-. \n");
                  System.out.println("\tOpcion: ");
                  int i=teclado.nextInt();
                  i--;
                  teclado.nextLine();
                  String[] s={"Corte de pelo","No agregado"};
                  String servicio=s[i];
                  System.out.println("Ingrese su nombre: ");
                  String cliente = teclado.nextLine();
                  System.out.println("Ingrese su número: ");
                  String numero = teclado.nextLine();
                  
                  reservacion.Reservar(cliente, numero, servicio, id);  
                  id++;
                  aux=0;
                  break;
              case 2:
                  reservacion.imprimirReservas();
                  break;
              case 3:
                  
                  break;
              case 4:
                  aux=1;
                  break;
              default:
                  System.out.println("Escoja una opción válida. \n");
                  break;
          }
          
        }while(aux==0);
    }
}
