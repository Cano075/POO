
package Servicios;

/**
 *
 * @author admin
 */
public class CorteDePelo  extends Servicios{
   
    CorteDePelo cita = new CorteDePelo();
    
    public void main(String[] args){
        setNombreServicio("Corte de Pelo");
        setCostoServicio(200.00);
    }
    
}
