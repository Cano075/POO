/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import java.io.File;
import java.io.FileNotFoundException;

public class pruebas {

    public static void main(String[] args) {
        File f = new File("src\\hola.txt");
        if (f.exists()) {
            System.out.println("Nombre del archivo" + f.getName());
            System.out.println("Camino" + f.getPath());
            System.out.println("Camino absoluto" + f.getAbsolutePath());
            System.out.println("Se puede escribir" + f.canRead());
            System.out.println("Se puede leer" + f.canWrite());
            System.out.println("Tamaño " + f.length());
        }
    }
}
