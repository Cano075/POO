package PIA;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Venta {

    private String cliente;
    private String numero;
    private String servicio;
    private int nTicket;
    private double total;

    Venta[] venta = new Venta[10];

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getServicio() {
        return servicio;
    }

    public void setServicio(String servicio) {
        this.servicio = servicio;
    }

    public int getID() {
        return nTicket;
    }

    public void setID(int ID) {
        this.nTicket = ID;
    }

    public Venta(String cliente, String numero, Servicios servicios, int ID) {
        this.cliente = cliente;
        this.numero = numero;
        this.servicio = servicios.getNombreServicio();
        this.nTicket = ID;
        this.total = servicios.getCostoServicio();
    }

    public Venta() {

    }

    public void Vender(String cliente, String numero, Servicios servicios, int ID) {
        venta[ID] = new Venta(cliente, numero, servicios, ID);
    }

    public void imprimirVentas() {
        int x = 0;
        System.out.println("Información de las ventas: \n");
        System.out.println("==============================================\n");
        while (venta[x] != null) {
            System.out.print(venta[x]);
            x++;
        }
    }

    @Override
    public String toString() {
        return  "Número de ticket: " + nTicket + "\n"
                + "Cliente: " + cliente + "\n"
                + "Numero: " + numero + "\n"
                + "Servicio: " + servicio + "\n"
                + "Total: " + total + "\n" +
                "==============================================\n";
    }

    public boolean validarBusqueda(int x) {
        int i = 0;
        while (venta[i] != null) {
            if (venta[i].nTicket == x) {
                return true;
            }
            i++;
        }
        return false;
    }

    public void buscar() {
        int aux = 0;
        int opc;
        boolean match=false;
        Scanner teclado = new Scanner(System.in);
        System.out.println("Buscar: \n");
        System.out.println("\tNúmero de Ticket: ");
        opc = teclado.nextInt();
        while(venta[aux]!=null){
            if(venta[aux].nTicket==opc){
                System.out.println("==============================================\n");
                System.out.println("Información de la venta: \n");
                System.out.println(venta[aux]);
                match=true;
                aux++;
            }
            else{
                aux++;
            }
        }
        if(!match)
            System.out.println("\tNúmero de Ticket no encontrado. \n");
        
    }

    public void modificarVenta(int ticket, String nuevoCliente, String nuevoServicio, String nuevoNumero) {
        venta[ticket].setServicio(nuevoServicio);
        venta[ticket].setCliente(nuevoCliente);
        venta[ticket].setNumero(nuevoNumero);
    }

}
